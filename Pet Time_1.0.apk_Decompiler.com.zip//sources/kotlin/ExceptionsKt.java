package kotlin;

@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/ExceptionsKt__ExceptionsKt"}, k = 4, mv = {1, 1, 13}, xi = 1)
/* compiled from: Exceptions.kt */
public final class ExceptionsKt extends ExceptionsKt__ExceptionsKt {
    private ExceptionsKt() {
    }
}
