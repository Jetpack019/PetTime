package kotlin;

@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/PreconditionsKt__AssertionsJVMKt", "kotlin/PreconditionsKt__PreconditionsKt"}, k = 4, mv = {1, 1, 13}, xi = 1)
public final class PreconditionsKt extends PreconditionsKt__PreconditionsKt {
    private PreconditionsKt() {
    }
}
