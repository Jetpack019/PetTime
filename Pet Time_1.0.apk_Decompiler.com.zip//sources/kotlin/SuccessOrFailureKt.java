package kotlin;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000(\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003*d\b\u0007\u0010\u0000\u001a\u0004\b\u0000\u0010\u0001\"\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0002B6\b\u0003\u0012\b\b\u0004\u0012\u0004\b\b(\u0005\u0012\n\b\u0006\u0012\u0006\b\n0\u00078\b\u0012\u001c\b\t\u0012\u0018\b\u000bB\u0014\b\n\u0012\u0006\b\u000b\u0012\u0002\b\f\u0012\b\b\f\u0012\u0004\b\b(\rB\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\b(\u0010¨\u0006\u0011"}, d2 = {"SuccessOrFailure", "T", "Lkotlin/Result;", "Lkotlin/Deprecated;", "message", "Renamed to Result", "level", "Lkotlin/DeprecationLevel;", "ERROR", "replaceWith", "Lkotlin/ReplaceWith;", "imports", "expression", "Result", "Lkotlin/SinceKotlin;", "version", "1.3", "kotlin-stdlib"}, k = 2, mv = {1, 1, 13})
/* compiled from: SuccessOrFailure.kt */
public final class SuccessOrFailureKt {
    @Deprecated(level = DeprecationLevel.ERROR, message = "Renamed to Result", replaceWith = @ReplaceWith(expression = "Result", imports = {}))
    public static /* synthetic */ void SuccessOrFailure$annotations() {
    }
}
