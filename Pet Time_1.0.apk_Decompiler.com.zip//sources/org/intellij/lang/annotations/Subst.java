package org.intellij.lang.annotations;

public @interface Subst {
    String value();
}
