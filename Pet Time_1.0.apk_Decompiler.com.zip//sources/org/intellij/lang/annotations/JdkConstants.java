package org.intellij.lang.annotations;

public class JdkConstants {

    public @interface AdjustableOrientation {
    }

    public @interface BoxLayoutAxis {
    }

    public @interface CalendarMonth {
    }

    public @interface CursorType {
    }

    public @interface FlowLayoutAlignment {
    }

    public @interface FontStyle {
    }

    public @interface HorizontalAlignment {
    }

    public @interface InputEventMask {
    }

    public @interface ListSelectionMode {
    }

    public @interface PatternFlags {
    }

    public @interface TabLayoutPolicy {
    }

    public @interface TabPlacement {
    }

    public @interface TitledBorderJustification {
    }

    public @interface TitledBorderTitlePosition {
    }

    public @interface TreeSelectionMode {
    }
}
