package org.intellij.lang.annotations;

public @interface Identifier {
}
