package kotlin.experimental;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\n\n\u0002\b\u0004\u001a\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0001H\f\u001a\u0015\u0010\u0000\u001a\u00020\u0003*\u00020\u00032\u0006\u0010\u0002\u001a\u00020\u0003H\f\u001a\r\u0010\u0004\u001a\u00020\u0001*\u00020\u0001H\b\u001a\r\u0010\u0004\u001a\u00020\u0003*\u00020\u0003H\b\u001a\u0015\u0010\u0005\u001a\u00020\u0001*\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0001H\f\u001a\u0015\u0010\u0005\u001a\u00020\u0003*\u00020\u00032\u0006\u0010\u0002\u001a\u00020\u0003H\f\u001a\u0015\u0010\u0006\u001a\u00020\u0001*\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0001H\f\u001a\u0015\u0010\u0006\u001a\u00020\u0003*\u00020\u00032\u0006\u0010\u0002\u001a\u00020\u0003H\f¨\u0006\u0007"}, d2 = {"and", "", "other", "", "inv", "or", "xor", "kotlin-stdlib"}, k = 2, mv = {1, 1, 13})
/* compiled from: bitwiseOperations.kt */
public final class BitwiseOperationsKt {
    private static final byte and(byte $receiver, byte other) {
        return (byte) ($receiver & other);
    }

    private static final byte or(byte $receiver, byte other) {
        return (byte) ($receiver | other);
    }

    private static final byte xor(byte $receiver, byte other) {
        return (byte) ($receiver ^ other);
    }

    private static final byte inv(byte $receiver) {
        return (byte) (~$receiver);
    }

    private static final short and(short $receiver, short other) {
        return (short) ($receiver & other);
    }

    private static final short or(short $receiver, short other) {
        return (short) ($receiver | other);
    }

    private static final short xor(short $receiver, short other) {
        return (short) ($receiver ^ other);
    }

    private static final short inv(short $receiver) {
        return (short) (~$receiver);
    }
}
