package org.intellij.lang.annotations;

public @interface PrintFormat {
}
